package com.clover_studio.spikachatmodule.view.stickers;

/**
 * Created by ubuntu_ivo on 24.07.15..
 */
public interface OnStickersManageListener {

    void onStickersOpened();
    void onStickersClosed();

}
