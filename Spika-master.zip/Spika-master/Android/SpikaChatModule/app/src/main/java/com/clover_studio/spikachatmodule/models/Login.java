package com.clover_studio.spikachatmodule.models;

import com.clover_studio.spikachatmodule.base.BaseModel;

/**
 * Created by ubuntu_ivo on 22.07.15..
 */
public class Login extends BaseModel {

    public LoginResult data;

}
