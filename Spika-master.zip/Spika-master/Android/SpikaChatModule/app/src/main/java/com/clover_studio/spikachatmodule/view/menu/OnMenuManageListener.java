package com.clover_studio.spikachatmodule.view.menu;

/**
 * Created by ubuntu_ivo on 24.07.15..
 */
public interface OnMenuManageListener {

    public void onMenuOpened();
    public void onMenuClosed();

}
